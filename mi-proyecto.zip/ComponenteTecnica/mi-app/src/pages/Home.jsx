import Navbar from '../components/Navbar/Navbar'
import Hero from '../components/Hero/Hero'
import Devices from '../components/Devices/Devices'
import Compare from '../components/Compare/Compare'
import Footer from '../components/Footer/Footer'
import './Home.css'

function Home({ theme, toggleTheme }) {
  return (
    <div className="home">
      <Navbar theme={theme} toggleTheme={toggleTheme} />
      <Hero />
      <Devices />
      <Compare />
      <Footer />
    </div>
  )
}

export default Home