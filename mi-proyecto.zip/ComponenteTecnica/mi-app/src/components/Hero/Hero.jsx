import './Hero.css'

function Hero() {
  return (
    <section className="hero">
      <div className="hero__content">

        <div className="hero__badge">
          <span className="hero__badge-dot"></span>
          Comparador Técnico 2025
        </div>

        <h1 className="hero__title">
          Elige el dispositivo<br />
          <span>perfecto para ti</span>
        </h1>

        <p className="hero__subtitle">
          Compara las especificaciones técnicas de los 4 mejores dispositivos
          del mercado. Procesadores, pantallas, baterías y más, lado a lado.
        </p>

        <div className="hero__actions">
          <a href="#dispositivos" className="hero__btn">Ver dispositivos →</a>
          <a href="#comparador" className="hero__btn hero__btn--outline">Comparar ahora</a>
        </div>

        <div className="hero__stats">
          <div>
            <div className="hero__stat-number">4</div>
            <div className="hero__stat-label">Dispositivos</div>
          </div>
          <div>
            <div className="hero__stat-number">12+</div>
            <div className="hero__stat-label">Especificaciones</div>
          </div>
          <div>
            <div className="hero__stat-number">100%</div>
            <div className="hero__stat-label">Datos reales</div>
          </div>
        </div>

      </div>
    </section>
  )
}

export default Hero