import './Footer.css'

function Footer() {
  return (
    <footer className="footer" id="footer">
      <div className="footer__logo">TechCompare</div>
      <p className="footer__text">© 2025 TechCompare — Todos los derechos reservados</p>
      <p className="footer__sub">Hecho con React ⚡ Datos oficiales de cada fabricante</p>
    </footer>
  )
}

export default Footer