import { Link } from 'react-router-dom'
import './Navbar.css'

function Navbar({ theme, toggleTheme }) {

  const scrollToTop = (e) => {
    e.preventDefault()
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  return (
    <nav className="navbar">
      <div className="navbar__logo" onClick={scrollToTop}>
        <span className="navbar__logo-dot"></span>
        TechCompare
      </div>

      <ul className="navbar__links">
        <li>
          <button className="nav-link" onClick={scrollToTop}>Inicio</button>
        </li>
        <li className="nav-hide">
          <a href="#dispositivos">Dispositivos</a>
        </li>
        <li className="nav-hide">
          <a href="#comparador">Comparar</a>
        </li>
        <li className="nav-hide">
          <a href="#footer">Contacto</a>
        </li>
      </ul>

      <div className="navbar__right">
        <button
          className="navbar__toggle"
          onClick={toggleTheme}
          title={theme === 'dark' ? 'Modo claro' : 'Modo oscuro'}
        >
          <span className="navbar__toggle-thumb">
            {theme === 'dark' ? '🌙' : '☀️'}
          </span>
        </button>
      </div>
    </nav>
  )
}

export default Navbar