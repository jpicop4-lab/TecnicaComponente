import './Compare.css'

const filas = [
  {
    label: 'Procesador',
    valores: ['Apple A18 Pro (3nm)', 'Snapdragon 8 Elite (3nm)', 'Apple M4 Pro (3nm)', 'Intel Ultra 9 185H'],
    mejorIdx: 2,
  },
  {
    label: 'RAM',
    valores: ['8 GB LPDDR5', '12 GB LPDDR5X', '24 GB Unificada', '32 GB DDR5'],
    mejorIdx: 3,
  },
  {
    label: 'Almacenamiento',
    valores: ['hasta 1 TB', 'hasta 1 TB', 'hasta 2 TB SSD', '1 TB NVMe PCIe4'],
    mejorIdx: 2,
  },
  {
    label: 'Pantalla',
    valores: ['6.9" OLED 120Hz', '6.9" AMOLED 2X 120Hz', '14.2" Retina XDR 120Hz', '16" OLED 240Hz'],
    mejorIdx: 3,
  },
  {
    label: 'Cámara principal',
    valores: ['48 MP', '200 MP', '12 MP webcam', '1080p webcam'],
    mejorIdx: 1,
  },
  {
    label: 'Batería',
    valores: ['4,685 mAh', '5,000 mAh', '72.4 Wh · 24h', '90 Wh · 10h'],
    mejorIdx: 2,
  },
  {
    label: 'Carga rápida',
    valores: ['30W', '45W', '96W MagSafe', '240W'],
    mejorIdx: 3,
  },
  {
    label: 'Conectividad',
    valores: ['Wi-Fi 7 · 5G', 'Wi-Fi 7 · 5G', 'Wi-Fi 6E · TB5', 'Wi-Fi 6E · HDMI 2.1'],
    mejorIdx: 0,
  },
  {
    label: 'Sistema',
    valores: ['iOS 18', 'Android 15', 'macOS Sequoia', 'Windows 11'],
    mejorIdx: null,
  },
  {
    label: 'Precio base',
    valores: ['$1,199', '$1,299', '$1,999', '$2,099'],
    mejorIdx: 0,
  },
]

const dispositivos = [
  { nombre: 'iPhone 16 Pro Max',  marca: 'Apple',   emoji: '📱', color: '#f5f5f5', score: 91 },
  { nombre: 'Galaxy S25 Ultra',   marca: 'Samsung', emoji: '🤖', color: '#a78bfa', score: 93 },
  { nombre: 'MacBook Pro M4 Pro', marca: 'Apple',   emoji: '💻', color: '#34d399', score: 97 },
  { nombre: 'ROG Zephyrus G16',   marca: 'ASUS',    emoji: '🎮', color: '#f59e0b', score: 89 },
]

function ScoreBar({ score, color }) {
  return (
    <div className="compare__score">
      <span className="compare__score-val">{score}/100</span>
      <div className="compare__score-bar-wrap">
        <div
          className="compare__score-bar"
          style={{ width: `${score}%`, '--bar-color': color }}
        />
      </div>
    </div>
  )
}

function Compare() {
  return (
    <section className="compare" id="comparador">
      <div className="compare__header">
        <span className="compare__label">Análisis técnico</span>
        <h2 className="compare__heading">Comparativa lado a lado</h2>
        <p className="compare__sub">Todas las especificaciones clave en una sola tabla</p>
      </div>

      <div className="compare__wrapper">
        <table className="compare__table">
          <thead>
            <tr>
              <th className="compare__th-blank" />
              {dispositivos.map((d, i) => (
                <th className="compare__th" key={i}>
                  <span className="compare__th-emoji">{d.emoji}</span>
                  <div className="compare__th-device">{d.nombre}</div>
                  <div className="compare__th-brand">{d.marca}</div>
                  <div className="compare__th-color" style={{ background: d.color }} />
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            <tr>
              <td className="compare__td-label">Score global</td>
              {dispositivos.map((d, i) => (
                <td className="compare__td" key={i}>
                  <ScoreBar score={d.score} color={d.color} />
                </td>
              ))}
            </tr>
            {filas.map((fila, fi) => (
              <tr key={fi}>
                <td className="compare__td-label">{fila.label}</td>
                {fila.valores.map((val, vi) => (
                  <td
                    className={`compare__td ${vi === fila.mejorIdx ? 'compare__td--best' : ''}`}
                    key={vi}
                  >
                    {vi === fila.mejorIdx ? <strong>✓ {val}</strong> : val}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  )
}

export default Compare