import { useState } from 'react'
import './Devices.css'

const dispositivosData = [
  {
    id: 1,
    emoji: '📱',
    marca: 'Apple',
    nombre: 'iPhone 16 Pro Max',
    precio: '$1,199',
    accentColor: '#0071e3',
    destacado: true,
    specs: [
      { icon: '⚙️', label: 'Procesador',     valor: 'Apple A18 Pro (3nm)' },
      { icon: '🧠', label: 'RAM',             valor: '8 GB LPDDR5' },
      { icon: '💾', label: 'Almacenamiento',  valor: '256 GB / 512 GB / 1 TB' },
      { icon: '🖥️', label: 'Pantalla',        valor: '6.9" Super Retina XDR OLED · 2868×1320 · 120Hz ProMotion' },
      { icon: '📷', label: 'Cámara',          valor: '48 MP principal + 48 MP ultra + 12 MP telephoto 5x' },
      { icon: '🔋', label: 'Batería',         valor: '4,685 mAh · Carga 30W · Inalámbrica 25W MagSafe' },
      { icon: '📡', label: 'Conectividad',    valor: '5G · Wi-Fi 7 · Bluetooth 5.3 · NFC · USB-C 3.0' },
      { icon: '🛡️', label: 'Sistema',         valor: 'iOS 18' },
      { icon: '📐', label: 'Dimensiones',     valor: '163 × 77.6 × 8.25 mm · 227 g' },
    ],
  },
  {
    id: 2,
    emoji: '🤖',
    marca: 'Samsung',
    nombre: 'Galaxy S25 Ultra',
    precio: '$1,299',
    accentColor: '#a78bfa',
    destacado: false,
    specs: [
      { icon: '⚙️', label: 'Procesador',     valor: 'Snapdragon 8 Elite for Galaxy (3nm)' },
      { icon: '🧠', label: 'RAM',             valor: '12 GB LPDDR5X' },
      { icon: '💾', label: 'Almacenamiento',  valor: '256 GB / 512 GB / 1 TB (UFS 4.0)' },
      { icon: '🖥️', label: 'Pantalla',        valor: '6.9" Dynamic AMOLED 2X · 1440×3088 · 120Hz LTPO' },
      { icon: '📷', label: 'Cámara',          valor: '200 MP principal + 12 MP ultra + 50 MP tele 5x + 10 MP tele 3x' },
      { icon: '🔋', label: 'Batería',         valor: '5,000 mAh · Carga 45W · Inalámbrica 15W' },
      { icon: '📡', label: 'Conectividad',    valor: '5G · Wi-Fi 7 · Bluetooth 5.4 · NFC · USB-C 3.2' },
      { icon: '🛡️', label: 'Sistema',         valor: 'Android 15 · One UI 7' },
      { icon: '📐', label: 'Dimensiones',     valor: '162.8 × 79 × 8.2 mm · 218 g' },
    ],
  },
  {
    id: 3,
    emoji: '💻',
    marca: 'Apple',
    nombre: 'MacBook Pro 14" M4 Pro',
    precio: '$1,999',
    accentColor: '#34d399',
    destacado: false,
    specs: [
      { icon: '⚙️', label: 'Procesador',     valor: 'Apple M4 Pro · 12-core CPU · 20-core GPU · 16-core Neural Engine' },
      { icon: '🧠', label: 'RAM',             valor: '24 GB RAM unificada (ampliable a 48 GB)' },
      { icon: '💾', label: 'Almacenamiento',  valor: 'SSD 512 GB / 1 TB / 2 TB (hasta 7.4 GB/s)' },
      { icon: '🖥️', label: 'Pantalla',        valor: '14.2" Liquid Retina XDR · 3024×1964 · 120Hz ProMotion · 1600 nits' },
      { icon: '📷', label: 'Cámara',          valor: 'Webcam 12 MP Center Stage con ISP M4' },
      { icon: '🔋', label: 'Batería',         valor: '72.4 Wh · hasta 24h · Carga 96W MagSafe 3' },
      { icon: '📡', label: 'Conectividad',    valor: 'Wi-Fi 6E · Bluetooth 5.3 · Thunderbolt 5 (x3) · HDMI 2.1 · SD' },
      { icon: '🛡️', label: 'Sistema',         valor: 'macOS Sequoia' },
      { icon: '📐', label: 'Dimensiones',     valor: '31.26 × 22.12 × 1.55 cm · 1.6 kg' },
    ],
  },
  {
    id: 4,
    emoji: '🎮',
    marca: 'ASUS',
    nombre: 'ROG Zephyrus G16',
    precio: '$2,099',
    accentColor: '#f59e0b',
    destacado: false,
    specs: [
      { icon: '⚙️', label: 'Procesador',     valor: 'Intel Core Ultra 9 185H · hasta 5.1 GHz · 16 núcleos' },
      { icon: '🧠', label: 'RAM',             valor: '32 GB DDR5-7500 MHz (2× SO-DIMM)' },
      { icon: '💾', label: 'Almacenamiento',  valor: 'SSD NVMe 1 TB PCIe 4.0 (2× M.2)' },
      { icon: '🖥️', label: 'Pantalla',        valor: '16" OLED 2.5K · 2560×1600 · 240Hz · 0.2ms · DCI-P3 100%' },
      { icon: '📷', label: 'Cámara',          valor: 'IR 1080p 60fps · Windows Hello · Noise Cancellation AI' },
      { icon: '🔋', label: 'Batería',         valor: '90 Wh · Carga 240W GaN · hasta 10h uso normal' },
      { icon: '📡', label: 'Conectividad',    valor: 'Wi-Fi 6E · Bluetooth 5.3 · USB-C 4.0 · USB-A 3.2 · HDMI 2.1' },
      { icon: '🛡️', label: 'Sistema',         valor: 'Windows 11 Home · GPU NVIDIA RTX 4070 8 GB GDDR6' },
      { icon: '📐', label: 'Dimensiones',     valor: '35.4 × 24.3 × 1.49 cm · 1.85 kg' },
    ],
  },
]

function Modal({ device, onClose }) {
  return (
    <div className="modal-overlay" onClick={onClose}>
      <div
        className="modal"
        style={{ '--modal-accent': device.accentColor }}
        onClick={e => e.stopPropagation()}
      >
        <button className="modal__close" onClick={onClose}>✕</button>

        <span className="modal__emoji">{device.emoji}</span>
        <div className="modal__brand">{device.marca}</div>
        <h2 className="modal__name">{device.nombre}</h2>
        <div className="modal__price">Desde {device.precio}</div>

        <hr className="modal__divider" />

        <ul className="modal__specs">
          {device.specs.map((spec, i) => (
            <li className="modal__spec" key={i}>
              <span className="modal__spec-icon">{spec.icon}</span>
              <div className="modal__spec-info">
                <span className="modal__spec-label">{spec.label}</span>
                <span className="modal__spec-value">{spec.valor}</span>
              </div>
            </li>
          ))}
        </ul>

        <button className="modal__btn" onClick={onClose}>Cerrar</button>
      </div>
    </div>
  )
}

function DeviceCard({ device, onClick }) {
  return (
    <div
      className={`device-card ${device.destacado ? 'device-card--featured' : ''}`}
      style={{ '--card-accent': device.accentColor }}
      onClick={() => onClick(device)}
    >
      {device.destacado && (
        <span className="device-card__featured-badge">★ Top Pick</span>
      )}
      <span className="device-card__emoji">{device.emoji}</span>
      <div className="device-card__brand">{device.marca}</div>
      <h3 className="device-card__name">{device.nombre}</h3>
      <div className="device-card__price">Desde {device.precio}</div>
      <span className="device-card__hint">Ver especificaciones →</span>
    </div>
  )
}

function Devices() {
  const [selected, setSelected] = useState(null)

  return (
    <section className="devices" id="dispositivos">
      <div className="devices__header">
        <span className="devices__label">Catálogo 2025</span>
        <h2 className="devices__heading">Los 4 mejores dispositivos</h2>
        <p className="devices__sub">
          Toca cualquier dispositivo para ver todas sus especificaciones.
        </p>
      </div>

      <div className="devices__grid">
        {dispositivosData.map((device) => (
          <DeviceCard key={device.id} device={device} onClick={setSelected} />
        ))}
      </div>

      {selected && (
        <Modal device={selected} onClose={() => setSelected(null)} />
      )}
    </section>
  )
}

export default Devices